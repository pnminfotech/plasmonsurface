<nav class="navbar navbar-expand-lg navbar-dark px-5  py-lg-0">
            <a href="index.php" class="navbar-brand p-0">
                <!-- <h1 class="m-0"></h1> -->
                <img src="img/plasmon-logo.jpeg" class="img-fluid logo-img" alt="">
                
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="fa fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto py-0">
                    <a href="index.php" class="nav-item nav-link active">Home</a>
                    
                    <div class="nav-item   dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">About</a>
                        <div class="dropdown-menu m-0">
                            <a href="profile.php" class="dropdown-item">Company profile</a>
                            <a href="specification.php" class="dropdown-item">Technical Specification</a>
                        </div>
                    </div>

                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Services</a>
                        <div class="dropdown-menu m-0">
                            <a href="plasma-nitriding.php" class="dropdown-item">Plasma - Nitriding</a>
                            <a href="plasma-carbonitriding.php" class="dropdown-item">Plasma - Carbo Nitriding</a>
                            <a href="nitrocarburising.php" class="dropdown-item">Plasma - Nitrocarburising</a>
                            <a href="Assit-gas-carburising.php" class="dropdown-item">Plasma - Assit Gas-Carburising</a>
                            <a href="glass-bidding.php" class="dropdown-item">Glass bidding/Dry blasting</a>
                            <a href="post-oxidation.php" class="dropdown-item">Ion Nitriding with Post oxidation</a>
                        </div>
                    </div>
                   
                    <div class="nav-item ">
                        <a href="applications.php" class="nav-link " >Applications</a>
                        
                    </div>
                    <a href="contact.php" class="nav-item nav-link">Contact</a>
                </div>
                <!-- <butaton type="button" class="btn text-warning ms-3" data-bs-toggle="modal" data-bs-target="#searchModal"><i class="fa fa-search"></i></butaton> -->
                <a href="contact.php" class="btn btn-warning py-2 px-4 ms-3">Enquiries</a>
            </div>
        </nav>

       